package fr.nix.agribot

import net.fabricmc.api.ClientModInitializer

object AgriBotClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}